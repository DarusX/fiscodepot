<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Payments;
use Faker\Generator as Faker;

$factory->define(Payments::class, function (Faker $faker) {
    return [
        //
    ];
});
